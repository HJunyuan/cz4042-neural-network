import tensorflow as tf
import numpy as np
import pylab as plt
import pandas as pd 
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import RFE

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
# ======================================== #
NUM_FEATURES = 7
NUM_OUTPUTS = 1

learning_rate = 0.001
epochs = 200
batch_size = 8
beta = 0.001
num_hidden_layer_neuron = 10
seed = 100
np.random.seed(seed)

# ======================================== #
#Getting data for the 3 layer network from Question 2 
admit_data = np.genfromtxt('admission_predict.csv', delimiter= ',')
X_data, Y_data = admit_data[1:,1:8], admit_data[1:,-1]
Y_data = Y_data.reshape(Y_data.shape[0], 1) # 1 colmun matrix

X_data = (X_data - np.mean(X_data, axis=0))/ np.std(X_data, axis=0) #Normal Distribution

#Shuffling the data
idx = np.arange(X_data.shape[0]) 
np.random.shuffle(idx) #shuffling the index 
X_data, Y_data = X_data[idx], Y_data[idx] #Giving the data with shuffled indexes

#spliting the data 70:30
X_data_Train, X_data_Test, Y_data_Train, Y_data_Test = train_test_split(X_data, Y_data, test_size = 0.3)

num_data_7_feature = len(X_data_Train)

#Question 3 of getting the data#
admission_data = pd.read_csv('admission_predict.csv')
admission_data.drop('Serial No.', axis = 1, inplace = True) 
admission_data_feature_6 = admission_data.drop('SOP', axis = 1)   #University rating  #GRE Score #Research <------ ***** change here to remove the feature *****
admission_data_feature_5 = admission_data_feature_6.drop('University Rating', axis = 1) #SOP <------- ***** change here to remove the feature *****
#corrmat = admission_data.corr()
#f, ax = plt.subplots(figsize=(12,10))
#plt.figure(figsize=(12,10))
#sns.heatmap(corrmat, annot = True,vmin=-1, vmax=1, center=0, cmap='coolwarm', linewidths=3, linecolor='black')

#After the observation of correlation matrix feature that will be remove will be Research and LOR as they have
#the lowest correlation with Chance of Admit

#Feature removed for Research
data_6feat = admission_data_feature_6.as_matrix()
X_data6, Y_data6 = data_6feat[:,:6],data_6feat[:,-1]
Y_data6 = Y_data6.reshape(Y_data6.shape[0],1)

X_data6 = (X_data6 - np.mean(X_data6, axis=0))/ np.std(X_data6, axis=0) #Normal Distribution 

idx = np.arange(X_data6.shape[0]) 
np.random.shuffle(idx) #shuffling the index 
X_data6, Y_data6 = X_data6[idx], Y_data6[idx] #Giving the data with shuffled indexes

#spliting the data 70:30
X_data6_Train, X_data6_Test, Y_data6_Train, Y_data6_Test = train_test_split(X_data6, Y_data6, test_size = 0.3)

num_data_6_feature = len(X_data6_Train)

#Feature removed for LOR
data_5feat = admission_data_feature_5.as_matrix()
X_data5, Y_data5 = data_5feat[:,:5],data_5feat[:,-1]
Y_data5 = Y_data5.reshape(Y_data5.shape[0],1)

X_data5 = (X_data5 - np.mean(X_data5, axis=0))/ np.std(X_data5, axis=0) #Normal Distribution

idx = np.arange(X_data5.shape[0]) 
np.random.shuffle(idx) #shuffling the index 
X_data5, Y_data5 = X_data5[idx], Y_data5[idx] #Giving the data with shuffled indexes

#spliting the data 70:30
X_data5_Train, X_data5_Test, Y_data5_Train, Y_data5_Test = train_test_split(X_data5, Y_data5, test_size = 0.3)

num_data_5_feature = len(X_data5_Train)

# ============================= Create Function ============================= #

def model(trainX, trainY, testX, testY, num_data ,NUM_FEATURES ,learning_rate = 0.001, epochs = 200, batch_size = 8, num_hidden_layer_neuron = 10, beta = 0.001, plot_test = True, dropout = False):

    x = tf.placeholder(tf.float32, [None, NUM_FEATURES])
    y_ = tf.placeholder(tf.float32, [None, NUM_OUTPUTS])

    # Build the graph for deep net 3 layers
    weights_1 = tf.Variable(tf.truncated_normal([NUM_FEATURES, num_hidden_layer_neuron], stddev=1.0 / np.sqrt(float(NUM_FEATURES)), dtype=tf.float32), name='weights_1')
    
    biases_1 = tf.Variable(tf.zeros([num_hidden_layer_neuron]),dtype=tf.float32 ,name='biases_1')
    
    weights_2 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron, NUM_OUTPUTS], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron)),dtype=tf.float32), name='weights_2')
    
    biases_2 = tf.Variable(tf.zeros([NUM_OUTPUTS]), dtype=tf.float32,name='biases_2')

    # Forward propogation 
    I1 = tf.matmul(x,weights_1) + biases_1
    H1 = tf.nn.relu(I1)
    if dropout:
        H1 = tf.nn.dropout(H1, keep_prob = 0.8)
    output_y = tf.matmul(H1,weights_2) + biases_2
    if dropout:
        output_y = tf.nn.dropout(output_y, keep_prob = 0.8)

    y = output_y # linear output

    error = tf.reduce_mean(tf.square(y_ - y)) #Normal loss function

    # Loss function with L2 Regularization with beta = 0.001
    regularizers = tf.nn.l2_loss(weights_1) + tf.nn.l2_loss(weights_2)
    loss = tf.reduce_mean(error + beta * regularizers)

    # Optimizer
    train_op = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        train_err = []
        test_err = []
        predicted_value = []
        idx = np.arange(num_data)
        len_batch_size = np.ceil(num_data/batch_size)
         
        for i in range(epochs):
            np.random.shuffle(idx)
            trainX = trainX[idx]
            trainY = trainY[idx]

            batch_loss = 0
            # Created mini batches for training during epochs
            for start, end in zip(range(0, num_data, batch_size), range(batch_size, num_data, batch_size)):
                train_op.run(feed_dict={x: trainX[start:end], y_: trainY[start:end]})
                batch_loss += loss.eval(feed_dict={x: trainX[start:end], y_: trainY[start:end]})
                
                
            train_err.append(batch_loss/len_batch_size)
            

            prediction = np.squeeze(y.eval(feed_dict={x: testX}))
        
            epoch_test_error_ = np.mean(np.square(prediction - testY))
            
            test_err.append(epoch_test_error_)

            if i % 50 == 0:
                print('iter %d: train error %g'%(i, train_err[i]))
                print('iter %d: test error %g'%(i, test_err[i]))
            if i == 199:
                print('At 200 iter: test error at this point is %g'%(test_err[i]))
            if i == 499:
                print('At 500 iter: test error at this point is %g'%(test_err[i]))
    
        predicted_value = y.eval(feed_dict={x: testX})
        
        if plot_test:
            # plot test error and predicted values
            plt.figure(3)
            plt.scatter(range(50), predicted_value[:50])
            plt.plot(range(50), predicted_value[:50], label = 'prediction')
            plt.scatter(range(50), Y_data_Test[:50])
            plt.plot(range(50), Y_data_Test[:50], label = 'actual')
            plt.xlabel('Samples')
            plt.ylabel('Values')
            plt.legend()
            plt.savefig('PartB_Question3.png')
            plt.show()

        return train_err, test_err


def model_4_layers(trainX, trainY, testX, testY, num_data ,NUM_FEATURES ,learning_rate = 0.001, epochs = 200, batch_size = 8, num_hidden_layer_neuron = [50,50], beta = 0.001, plot_test = False, dropout = True):
     prob = 0.8
     
     x = tf.placeholder(tf.float32, [None, NUM_FEATURES])
     y_ = tf.placeholder(tf.float32, [None, NUM_OUTPUTS])

     keep_prob = tf.placeholder(tf.float32)

     # Build the graph for deep net 4 layers
     weights_1 = tf.Variable(tf.truncated_normal([NUM_FEATURES, num_hidden_layer_neuron[0]], stddev=1.0 / np.sqrt(float(NUM_FEATURES)), dtype=tf.float32), name='weights_1')
    
     biases_1 = tf.Variable(tf.zeros([num_hidden_layer_neuron[0]]),dtype=tf.float32 ,name='biases_1')
    
     weights_2 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron[0], num_hidden_layer_neuron[1]], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron[0])),dtype=tf.float32), name='weights_2')
    
     biases_2 = tf.Variable(tf.zeros(num_hidden_layer_neuron[1]), dtype=tf.float32,name='biases_2')

     weights_3 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron[1], NUM_OUTPUTS], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron[1])),dtype=tf.float32), name='weights_3')
    
     biases_3 = tf.Variable(tf.zeros([NUM_OUTPUTS]), dtype=tf.float32,name='biases_3')

     # Forward propogation 4 layers
     M1 = tf.matmul(x,weights_1) + biases_1
     H1 = tf.nn.relu(M1)
     if dropout:
         H1 = tf.nn.dropout(H1, keep_prob)

     M2 = tf.matmul(H1,weights_2) + biases_2
     H2 = tf.nn.relu(M2)
     if dropout:
         H2 = tf.nn.dropout(H2, keep_prob)
     
     M3 = tf.matmul(H2,weights_3) + biases_3
     if dropout:
         M3 = tf.nn.dropout(M3, keep_prob)

     y = M3 # linear output

     error = tf.reduce_mean(tf.square(y_ - y)) #Normal loss function

     # Loss function with L2 Regularization with beta = 0.001
     regularizers = tf.nn.l2_loss(weights_1) + tf.nn.l2_loss(weights_2) + tf.nn.l2_loss(weights_3)
     loss = tf.reduce_mean(error + beta * regularizers)

     # Optimizer
     train_op = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

     with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        train_err = []
        test_err = []
        predicted_value = []
        idx = np.arange(num_data)
        len_batch_size = np.ceil(num_data/batch_size)
         
        for i in range(epochs):
            np.random.shuffle(idx)
            trainX = trainX[idx]
            trainY = trainY[idx]

            batch_loss = 0
            # Created mini batches for training during epochs
            for start, end in zip(range(0, num_data, batch_size), range(batch_size, num_data, batch_size)):
                train_op.run(feed_dict={x: trainX[start:end], y_: trainY[start:end], keep_prob : prob})
                batch_loss += loss.eval(feed_dict={x: trainX[start:end], y_: trainY[start:end], keep_prob:prob})
                
                
            train_err.append(batch_loss/len_batch_size)
            

            prediction = np.squeeze(y.eval(feed_dict={x: testX , keep_prob: 1.0}))
        
            epoch_test_error_ = np.mean(np.square(prediction - testY))
            
            test_err.append(epoch_test_error_)

            if i % 50 == 0:
                print('iter %d: train error %g'%(i, train_err[i]))
                print('iter %d: test error %g'%(i, test_err[i]))
            if i == 999:
                    print('At 1000 iter: 4 layer test error(without dropout) at this point is %g'%(test_err[i]))
            
            if dropout == True:
                if i == 999:
                    print('At 1000 iter: 4 layer test error(with dropout) at this point is %g'%(test_err[i]))
        
        predicted_value = y.eval(feed_dict={x: testX, keep_prob : 1.0})
        
        if plot_test:
            # plot test error and predicted values
            plt.figure(3)
            plt.scatter(range(50), predicted_value[:50])
            plt.plot(range(50), predicted_value[:50], label = 'prediction')
            plt.scatter(range(50), Y_data_Test[:50])
            plt.plot(range(50), Y_data_Test[:50], label = 'actual')
            plt.xlabel('Samples')
            plt.ylabel('Values')
            plt.legend()
            plt.show()

        return train_err, test_err

def model_5_layers(trainX, trainY, testX, testY, num_data ,NUM_FEATURES ,learning_rate = 0.001, epochs = 200, batch_size = 8, num_hidden_layer_neuron = [50,50,50], beta = 0.001, plot_test = False, dropout = True):
     prob = 0.8
     
     x = tf.placeholder(tf.float32, [None, NUM_FEATURES])
     y_ = tf.placeholder(tf.float32, [None, NUM_OUTPUTS])
     keep_prob = tf.placeholder(tf.float32)

     # Build the graph for deep net 5 layers
     weights_1 = tf.Variable(tf.truncated_normal([NUM_FEATURES, num_hidden_layer_neuron[0]], stddev=1.0 / np.sqrt(float(NUM_FEATURES)), dtype=tf.float32), name='weights_1')
    
     biases_1 = tf.Variable(tf.zeros([num_hidden_layer_neuron[0]]),dtype=tf.float32 ,name='biases_1')
    
     weights_2 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron[0], num_hidden_layer_neuron[1]], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron[0])),dtype=tf.float32), name='weights_2')
    
     biases_2 = tf.Variable(tf.zeros(num_hidden_layer_neuron[1]), dtype=tf.float32,name='biases_2')

     weights_3 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron[1], num_hidden_layer_neuron[2]], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron[1])),dtype=tf.float32), name='weights_3')
    
     biases_3 = tf.Variable(tf.zeros([num_hidden_layer_neuron[2]]), dtype=tf.float32,name='biases_3')

     weights_4 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron[2], NUM_OUTPUTS], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron[2])),dtype=tf.float32), name='weights_4')
    
     biases_4 = tf.Variable(tf.zeros([NUM_OUTPUTS]), dtype=tf.float32,name='biases_4')

     # Forward propogation 5 layers
     M1 = tf.matmul(x,weights_1) + biases_1
     H1 = tf.nn.relu(M1)
     if dropout:
         H1 = tf.nn.dropout(H1, keep_prob)

     M2 = tf.matmul(H1,weights_2) + biases_2
     H2 = tf.nn.relu(M2)
     if dropout:
         H2 = tf.nn.dropout(H2, keep_prob)
     
     M3 = tf.matmul(H2,weights_3) + biases_3
     H3 = tf.nn.relu(M3)
     if dropout:
         H3 = tf.nn.dropout(H3, keep_prob)

     M4 = tf.matmul(H3,weights_4) + biases_4
     if dropout:
         M4 = tf.nn.dropout(M4, keep_prob)

     y = M4   # linear output

     error = tf.reduce_mean(tf.square(y_ - y)) #Normal loss function

     # Loss function with L2 Regularization with beta = 0.001
     regularizers = tf.nn.l2_loss(weights_1) + tf.nn.l2_loss(weights_2) + tf.nn.l2_loss(weights_3) + tf.nn.l2_loss(weights_4)
     loss = tf.reduce_mean(error + beta * regularizers)

     # Optimizer
     train_op = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

     with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        train_err = []
        test_err = []
        predicted_value = []
        idx = np.arange(num_data)
        len_batch_size = np.ceil(num_data/batch_size)
         
        for i in range(epochs):
            np.random.shuffle(idx)
            trainX = trainX[idx]
            trainY = trainY[idx]

            batch_loss = 0
            # Created mini batches for training during epochs
            for start, end in zip(range(0, num_data, batch_size), range(batch_size, num_data, batch_size)):
                train_op.run(feed_dict={x: trainX[start:end], y_: trainY[start:end], keep_prob:prob})
                batch_loss += loss.eval(feed_dict={x: trainX[start:end], y_: trainY[start:end], keep_prob:prob})
                
                
            train_err.append(batch_loss/len_batch_size)

            prediction = np.squeeze(y.eval(feed_dict={x: testX, keep_prob : 1.0}))
        
            epoch_test_error_ = np.mean(np.square(prediction - testY))
            
            test_err.append(epoch_test_error_)

            if i % 50 == 0:
                print('iter %d: train error %g'%(i, train_err[i]))
                print('iter %d: test error %g'%(i, test_err[i]))
            
            if i == 999:
                    print('At 1000 iter: 5 layer test error(without dropout) at this point is %g'%(test_err[i]))
            
            if dropout == True:
                if i == 999:
                    print('At 1000 iter: 5 layer test error(with dropout) at this point is %g'%(test_err[i]))
        
        predicted_value = y.eval(feed_dict={x: testX, keep_prob:1.0})
        
        if plot_test:
            # plot test error and predicted values
            plt.figure(3)
            plt.scatter(range(50), predicted_value[:50])
            plt.plot(range(50), predicted_value[:50], label = 'prediction')
            plt.scatter(range(50), Y_data_Test[:50])
            plt.plot(range(50), Y_data_Test[:50], label = 'actual')
            plt.xlabel('Samples')
            plt.ylabel('Values')
            plt.legend()
            plt.show()

        return train_err, test_err


def optimal_layers():
    epochs = 1000
    train_err_1, test_err_1 = model(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_5_feature,5, epochs = 1000,plot_test = False)
    train_err_4, test_err_4 = model_4_layers(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_5_feature,5, epochs = 1000,dropout = False)
    # hao model_4_layers(X_data5_Train, Y_data5_Test, X_data5_Test, Y_data5_Test,num_data_5_feature, NUM_FEATURES = 5 ,epochs = 200, batch_size = batch_size, num_hidden_layer_neuron = [20, 20], beta = beta, plot_test=False, dropout=False)

    train_err_5, test_err_5 = model_5_layers(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_5_feature,5, epochs = 1000,dropout = False)
    # hao model_5_layers(X_data5_Train, Y_data5_Test, X_data5_Test, Y_data5_Test, num_data_5_feature, NUM_FEATURES = 5 ,epochs = 200, batch_size = batch_size, num_hidden_layer_neuron = [20, 20, 20], beta = beta, plot_test=False, dropout=False)

    # with dropout
    train_err_4_do, test_err_4_do = model_4_layers(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_5_feature,5,epochs = 1000,dropout = True)
    # hao model_4_layers(X_data5_Train, Y_data5_Test, X_data5_Test, Y_data5_Test, num_data_5_feature, NUM_FEATURES = 5 ,epochs = 200, batch_size = batch_size, num_hidden_layer_neuron = [20, 20], beta = beta, plot_test=False, dropout=True)

    train_err_5_do, test_err_5_do = model_5_layers(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_5_feature,5,epochs = 1000,dropout = True)
    # hao model_5_layers(X_data5_Train, Y_data5_Test, X_data5_Test, Y_data5_Test, num_data_5_feature, NUM_FEATURES = 5 ,epochs = 200, batch_size = batch_size, num_hidden_layer_neuron = [20, 20, 20], beta = beta, plot_test=False, dropout=True)

    
    plt.plot(range(epochs), train_err_1, label="train error 3 layer")
    plt.plot(range(epochs), train_err_4, label="train error 4 layer")
    #plt.plot(range(epochs), test_err_4, label="test error 4 layer")
    plt.plot(range(epochs), train_err_5, label="train error 5 layer")
    #plt.plot(range(epochs), test_err_5, label="test error 5 layer")
    plt.xlabel('Epochs')
    plt.ylabel('Train errors')
    plt.legend()
    plt.savefig('3-layers-vs-4-layer-vs-5-layer(train).png')
    plt.close()
    
    
    plt.plot(range(epochs), test_err_1, label="test error 3 layer")
    #plt.plot(range(epochs), train_err_4, label="train error 4 layer")
    plt.plot(range(epochs), test_err_4, label="test error 4 layer")
    #plt.plot(range(epochs), train_err_5, label="train error 5 layer")
    plt.plot(range(epochs), test_err_5, label="test error 5 layer")
    plt.xlabel('Epochs')
    plt.ylabel('Test errors')
    plt.legend()
    plt.savefig('3-layers-vs-4-layer-vs-5-layer(test).png')
    plt.close()

    # plt.plot(range(epochs), train_err_4, label="train error 4 layer")
    plt.plot(range(epochs), test_err_4, label="test error 4 layer")
    # plt.plot(range(epochs), train_err_4_do, label="train error 4 layer, with dropout")
    plt.plot(range(epochs), test_err_4_do, label="test error 4 layer, with dropout")
    plt.xlabel('Epochs')
    plt.ylabel('Validation / test errors')
    plt.legend()
    plt.savefig('4-layer-dropout-vs-no-dropout.png')
    plt.close()

    #plt.plot(range(epochs), train_err_5, label="train error 5 layer")
    plt.plot(range(epochs), test_err_5, label="test error 5 layer")
    #plt.plot(range(epochs), train_err_5_do, label="train error 5 layer, with dropout")
    plt.plot(range(epochs), test_err_5_do, label="test error 5 layer, with dropout")
    plt.xlabel('Epochs')
    plt.ylabel('Test errors')
    plt.legend()
    plt.savefig('5-layer-dropout-vs-no-dropout.png')
    plt.close()
    plt.show()

def plot_learning_curve(epochs, train_err, test_err, figname):
    # plot learning curves
    plt.figure(1)
    plt.plot(range(epochs), train_err , label = 'Training error')
    plt.plot(range(epochs), test_err, label = 'Test error')
    plt.legend()
    plt.xlabel(str(epochs) + ' iterations')
    plt.ylabel('Errors')
    plt.title(figname)
    plt.savefig(figname)
    plt.show()

if __name__ == "__main__":

    #train_err_5, test_err_5 = model(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_6_feature,5,epochs=500 ,plot_test = False)
    #plot_learning_curve(500, train_err_5,test_err_5,'PartB_Question3_SOP_Uni_Rating_Removed')
    
    #train_err_6, test_err_6 = model(X_data6_Train, Y_data6_Train, X_data6_Test, Y_data6_Test, num_data_6_feature,6, epochs = 500,plot_test = False)
    #plot_learning_curve(500, train_err_6,test_err_6,'PartB_Question3_SOP removed')

    #train_err_1, test_err_1 = model(X_data_Train, Y_data_Train, X_data_Test, Y_data_Test, num_data_7_feature,7, epochs = 500,plot_test = False)
    #plot_learning_curve(500, train_err_1,test_err_1,'PartB_Question1_7_features')

    #train_err_2, test_err_2 = model_4_layers(X_data5_Train, Y_data5_Train, X_data5_Test, Y_data5_Test, num_data_5_feature,5,dropout=True)
    #plot_learning_curve(200, train_err_2,test_err_2,'PartB_Question4_Test_error_with_dropout_5_Feature_without_Uni_Rating_SOP')
    optimal_layers()
    #plot_learning_curve(epochs, train_err_1,test_err_1,'PartB_Question3_Test_error_6_feature_Research_removed')
    #plot_learning_curve(epochs, train_err_2,test_err_2,'PartB_Question3_Test_error_5_feature_LOR_removed')
    






