import numpy as np
import pylab as plt
import pandas as pd 
import seaborn as sns
from sklearn.model_selection import train_test_split

admission_data = pd.read_csv('admission_predict.csv')
admission_data.drop('Serial No.', axis = 1, inplace = True)
#admission_data.drop('Research', axis = 1, inplace = True)
#admission_data.drop('LOR', axis = 1, inplace = True)
corrmat = admission_data.corr()
#f, ax = plt.subplots(figsize=(12,10))
plt.figure(figsize=(12,10))
sns.heatmap(corrmat, annot = True,vmin=-1, vmax=1, center=0, cmap='coolwarm', linewidths=3, linecolor='black')
plt.title("Correlation Matrix")

plt.show()

