#
# Project 1, starter code part b
#

import tensorflow as tf
import numpy as np
import pylab as plt
import pandas as pd 
from sklearn.model_selection import train_test_split

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

NUM_FEATURES = 7

learning_rate = 0.001
epochs = 200
batch_size = 8
beta = 0.001
num_hidden_layer_neuron = 10
seed = 100
np.random.seed(seed)
        

#read and divide data into test and train sets 
admit_data = np.genfromtxt('admission_predict.csv', delimiter= ',')
X_data, Y_data = admit_data[1:,1:8], admit_data[1:,-1]
Y_data = Y_data.reshape(Y_data.shape[0], 1) # 1 colmun matrix

X_data = (X_data - np.mean(X_data, axis=0))/ np.std(X_data, axis=0) #Normal Distribution

#split data 70:30
# **sklearn test train split**
X_data_Train, X_data_Test, Y_data_Train, Y_data_Test = train_test_split(X_data, Y_data, test_size = 0.3)
print(X_data_Test.shape)

#some how arranging the array of X_data giving them a index
idx = np.arange(X_data_Train.shape[0]) 
np.random.shuffle(idx) #shuffling the index 
X_data_Train, Y_data_Train = X_data_Train[idx], Y_data_Train[idx] #Giving the data with shuffled indexes

# experiment with small datasets
# After shuffling the data, grabbing the first 100 data for X and Y
# Actual fact to create mini batches here

#trainX = X_data[:100]
#trainY = Y_data[:100]

num_data = len(X_data_Train) #getting number of data
    
# Create the model
x = tf.placeholder(tf.float32, [None, NUM_FEATURES]) # [row, columns] 
y_ = tf.placeholder(tf.float32, [None, 1]) # [row, columns]
    
# Build the graph for the deep net
weights_1 = tf.Variable(tf.truncated_normal([NUM_FEATURES, num_hidden_layer_neuron], stddev=1.0 / np.sqrt(float(NUM_FEATURES)), dtype=tf.float32), name='weights_1')

biases_1 = tf.Variable(tf.zeros([num_hidden_layer_neuron]),dtype=tf.float32 ,name='biases_1')
    
weights_2 = tf.Variable(tf.truncated_normal([num_hidden_layer_neuron, 1], stddev=1.0 / np.sqrt(float(num_hidden_layer_neuron)),dtype=tf.float32), name='weights_2')
    
biases_2 = tf.Variable(tf.zeros([1]), dtype=tf.float32,name='biases_2')

hidden_layer = tf.nn.relu(tf.matmul(x,weights_1) + biases_1) 
y = tf.matmul(hidden_layer, weights_2) + biases_2

# // Refer to Ritchie Ng to change output and numbers of nodes 
    
#Create the gradient descent optimizer with the given learning rate.
    
error = tf.reduce_mean(tf.square(y_ - y)) # Normal loss function
    
# Loss function with L2 Regularization with beta = 0.001
regularizers = tf.nn.l2_loss(weights_1) + tf.nn.l2_loss(weights_2)
loss = tf.reduce_mean(error + beta * regularizers)
    
# Optimizer
train_op = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    train_err = []
    test_err = []
    test_err2 = []
    predicted_value = []
    idx = np.arange(num_data)
    len_batch_size = np.ceil(num_data/batch_size)
    for i in range(epochs):
        np.random.shuffle(idx)
        X_data_Train = X_data_Train[idx]
        Y_data_Train = Y_data_Train[idx]

        batch_loss = 0
        count = 0
        # Created mini batches for training during epochs
        for start, end in zip(range(0, num_data, batch_size), range(batch_size, num_data, batch_size)):
            train_op.run(feed_dict={x: X_data_Train[start:end], y_: Y_data_Train[start:end]})
            batch_loss += loss.eval(feed_dict={x: X_data_Train[start:end], y_: Y_data_Train[start:end]})
            
            
        train_err.append(batch_loss/len_batch_size)
        test_err.append(loss.eval(feed_dict = {x: X_data_Test, y_ : Y_data_Test}))
        
        prediction = np.squeeze(y.eval(feed_dict={x: X_data_Test}))
        # Y_data_Test = np.squeeze(np.asarray(Y_data_Test))
        epoch_test_error_ = np.mean(np.square(prediction - Y_data_Test))
        test_err2.append(epoch_test_error_)

         
        if i % 50 == 0:
            print('iter %d: train error %g'%(i, train_err[i]))
            print('iter %d: test error %g'%(i, test_err[i]))
            print('iter %d: test error2 %g'%(i,test_err2[i]))
        if i == 199:
            print('At iter 200 train error %g'%(train_err[i]))
            print('At iter 200 train error %g'%(test_err[i]))
            print('At iter 200 train error %g'%(test_err2[i]))

    predicted_value = y.eval(feed_dict={x: X_data_Test})

# plot learning curves
plt.figure(1)
plt.plot(range(epochs), train_err , label = 'Training error')
# plt.plot(range(epochs), test_err, label = 'Test error')
plt.plot(range(epochs), test_err2, label = 'Test error 2')
plt.legend()
plt.xlabel(str(epochs) + ' iterations')
plt.ylabel('Errors')

plt.figure(2)
plt.plot(range(50), predicted_value[:50], label='Predicted value')
plt.plot(range(50), Y_data_Test[:50], label='Target values')
plt.xlabel('Samples')
plt.ylabel('Values')
plt.legend()

plt.figure(3)
plt.scatter(range(50), predicted_value[:50])
plt.plot(range(50), predicted_value[:50], label = 'prediction')
plt.scatter(range(50), Y_data_Test[:50])
plt.plot(range(50), Y_data_Test[:50], label = 'actual')
plt.xlabel('Samples')
plt.ylabel('Values')
plt.legend()

plt.show()
